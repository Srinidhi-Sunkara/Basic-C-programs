/*factorial using while 
#include<stdio.h>
void main()
{
	int n,sum=1,i;
	printf("enter a no:");
	scanf("%d",&n);
	i=1;
	while(i<=n)
	{
		sum=sum*i;
		i=i+1;	  	
	}
	printf("\n %d",sum);
}*/

