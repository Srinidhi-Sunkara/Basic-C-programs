#include<stdio.h>
void main()
{
	char a[100],sum="";
	int i;
	scanf("%s",&a);
	
    for(i=0;i<100;i++)
	{
		if(a[i]==".")
		a[i]="a";
	}
	for(i=0;i<100;i++)
	{
		printf("%s",a[i]);
	}
	
	
}
