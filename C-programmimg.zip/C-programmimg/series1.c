#include<stdio.h>
#include<math.h>
void main()
{
	int x,n,ch,i,sum=0;
	
	printf("a.1+3+5+...\nb.1sq+2sq+....\nc.1+x+x2+...\nd.1+1/x+...");
	printf("select a choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
			
			printf("enter the value of n");
			scanf("%d",&n);
			for(i=1;i<=n;i=i+2)
			{
				sum=sum+i;
			}
			printf("%d",sum);
			break;
		case 2:
		    
			printf("enter the value of n");
			scanf("%d",&n);
			for(i=1;i<=n;i=i+1)
			{
				sum=sum+(i*i);
			}
			printf("%d",sum);
			break;
		case 3:
			sum=1;
		    printf("enter the value of n");
			scanf("%d",&n);
			printf("enter the value of x:");
			scanf("%d",&x);
			for(i=1;i<n;i++)
			{
				sum=sum+pow(x,i);
			}
			printf("%d",sum);
			break;
		case 4:		
		    sum=1;
			printf("enter the value of n:");
			scanf("%d",&n);
			printf("enter the value of x:");
			scanf("%d",&x);
			for(i=1;i<n;i++)
			{
				sum=sum+(1/(pow(x,i)));
			}
			printf("%d",sum);
			break;	
	}
}
