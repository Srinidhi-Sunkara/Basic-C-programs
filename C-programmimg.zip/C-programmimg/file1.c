//writing and reading from a file
/*#include<stdio.h>
void main()
{
	int n,m;
	FILE *fp;
	fp=fopen("file1.txt","a+");
	printf("Enter a number:");
    scanf("%d",&n);
    fprintf(fp,"%d",n);
    rewind(fp);
    fscanf(fp,"%d",&m);
    printf("%d",m);
    fclose(fp);
}*/
#include<stdio.h>
void main()
{
	int n,i;
	FILE *fp,*fe,*fo;
	fp=fopen("file2.txt","w+");
	fe=fopen("file3.txt","w+");
	fo=fopen("file4.txt","w+");
	for(i=0;i<50;i++)
	{
		n=i+1;
		putw(n,fp);
	}
	rewind(fp);
	while((n=getw(fp))!=EOF){
		if(n%2==0)
		{
		putw(n,fe);printf("\n%d",n);}
		else
		putw(n,fo);
		printf("\n%d",n);
	}
}
