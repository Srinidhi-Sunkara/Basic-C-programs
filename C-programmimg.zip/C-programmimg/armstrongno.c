#include<stdio.h>
void main()
{
	int n,r,sum=0,temp;
	printf("enter no:");
	scanf("%d",&n);
	temp=n;
	while(n>0)
	{
		r=n%10;
		sum=sum+(r*r*r);
		n=n/10;		
	}
	if(temp==sum)
	{
		printf("entered number %d is an armstrong no",temp);
	}
	else
	printf("entered no is not an armstrong number");	
}
