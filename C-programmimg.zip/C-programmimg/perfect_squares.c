#include<stdio.h>
void main()
{
	int n,i;
	for(i=1;n<100;i++)
	{
		n=(i*i);
		printf("%d\n",n);
	}
}
