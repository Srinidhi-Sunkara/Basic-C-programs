/*#include<stdio.h>
void main()
{
	int i,j,temp,sum,r;
	for(i=1;i<=1000;i++)
	{
		sum=0;
		temp=i;
		j=i;
		while(j>0){
			r=j%10;
			sum=sum+(r*r*r);
			j=j/10;			
		}
		if(temp==sum)
		printf("%d\n",temp);
	}
}
//floyd triangle
#include<stdio.h>
void main()
{
	int fac=0,i,j;
	for(i=1;i<=5;i++)
	{
		for(j=0;j<i;j++)
		{
			fac++;
			printf("%d\t",fac);
		}
		printf("\n");
	}
}
//cos
#include<stdio.h>
void main()
{
	float sum,t,x;
	int i,n;
	scanf("%f",&x);
	scanf("%d",&n);
	x=x*(3.14159/180);
	t=1;
	sum=1;
	for(i=1;i<n;i++)
	{
		t=(t*-1*x*x)/(2*i*((2*i)-1));
		sum+=t;
	}
	
	
	printf("%f",sum);
}
#include<stdio.h>
void main()
{
	int i,j,sum=0,n;
	scanf("%d",&n);
	for(i=2;i<=n;i++)
	{
		
		for(j=1;j<=i;j++)
		{
			if(i%j==0)
			sum++;
		}
		if(sum==2)
		printf("%d\n",i);
	    sum=0;
	}
}
//prime numbers
#include<stdio.h>
void main()
{
	int i=3,count,c,n;
	scanf("%d",&n);
	printf("2\n");
	for(count=2;count<=n;i++){
		for(c=2;c<i;c++)
		{
			if(i%c==0)
			break;
		}
		if(i==c){
		printf("%d\n",c);
		count++;}
	}
}
#include<stdio.h>
void main()
{
	int a[10],n,i,j,k,x=0;
	printf("enter no:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		for(j=i+1;j<n;){
			if(a[i]==a[j]){
				for(k=j;k<n;k++){
					a[k]=a[k+1];
				}
				n--;
				x++;
			}
			else
			j++;
		}
	}
	for(i=0;i<n;i++){
		printf("%d\t",a[i]);
	}
	printf("%d",x);
}
#include<stdio.h>
int bs(int a[],int f,int l,int x);
void main()
{
	int a[10],f,l,x,i;
	int mid,m;
	for(i=0;i<4;i++)
	{
		scanf("%d",&a[i]);
	}
	m=bs(a,0,4,5);
	if(m==-1)
	printf("element not found");
	else
	printf("element found");
	
}
int bs(int a[],int f,int l,int x){
	while(f<=l){
		int mid;
		mid=(l+f)/2;
		if(a[mid]==x)
		return mid;
		if(a[mid]<x)
		return bs(a,mid+1,l,x);
		else if(a[mid]>x)
		return bs(a,f,mid-1,x);}
	
	    return -1;
		
		
	}
*/

#include<stdio.h>
void main()
{
	char a[100][100],temp;
	int i,j,small,n;
	fflush(stdin);
	printf("enter the no of names required:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		
		for(j=0;j<100;j++)
		scanf("%c",&a[i][j]);
	}
	for(i=0;i<n;i++)
	{
		small=i;
	    for(j=i+1;j<n;j++)
		{
			if(a[j][100]<a[i][100])
			small=j;
		}
		temp=a[small][100];
		a[small][100]=a[i][100];
		a[i][100]=temp;
	}
		for(i=0;i<n;i++)
	{
		printf("\n");
		for(j=0;j<n;j++)
		printf("%c",a[i][j]);
	}
	
}
