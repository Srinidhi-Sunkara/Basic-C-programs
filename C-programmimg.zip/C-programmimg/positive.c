#include<stdio.h>
void main()
{
	int n,i=0,k,j=0,l=0;
	printf("enter a no:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nenter a no:");
		scanf("%d",&k);
	    if(k<0)
		{
			printf("\nnegative no:%d",k);
			j=j+1;
		}
		else
		{
			printf("\npositive no:%d",k);
		    l=l+1;
		}
		
	}
	printf("\ntotal no of positive numbers:%d",l);
	printf("\ntotal no of negative numbers:%d",j);

}
