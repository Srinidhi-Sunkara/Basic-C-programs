#include<stdio.h>
void main()
{
	int n1,n2,temp;
	printf("enter two numbers:\n");
	scanf("%d%d",&n1,&n2);
	temp=n1;
	n1=n2;
	n2=temp;
	printf("after swapping:%d\t%d",n1,n2);
}
