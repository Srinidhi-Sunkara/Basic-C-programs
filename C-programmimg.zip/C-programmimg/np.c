#include<stdio.h>
void main()
{
  int N,temp,sum=0,r;
  printf("enter a no:");
  scanf("%d",&N);
  while(N>0)
  {
    r=n%10;
    sum=(sum*10)+r;
    n=n/10;
  }
  if(sum==temp)
    printf("YES");
  else
    printf("NO");
}
