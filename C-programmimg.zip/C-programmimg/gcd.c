/*#include<stdio.h>
void main()
{
	int n1,n2,min,i,gcd=0;
	printf("enter two numbers:");
	scanf("%d%d",&n1,&n2);
	if(n1>n2)
	min=n2;
	else
	min=n1;
	for(i=1;i<=min;i++)
	{
		if((n1%i==0)&&(n2%i==0))
		gcd=i;
	}
	printf("The gcd of %d and %d is %d",n1,n2,gcd);
}
#include<stdio.h>
void main()
{
	int n1,i,fac=0;
	printf("enter a no:");
	scanf("%d",&n1);
	for(i=1;i<=n1;i++)
	{
		if(n1%i==0)
		fac=fac+1;
	}
	if(fac==2)
	printf("entered number is a prime number:%d",n1);
	else
	printf("entered number is not a prime number");
}
#include<stdio.h>
void main()
{
	int u,i,j,fac=0;
	printf("enter the upper limit:");
	scanf("%d",&u);
	for(j=1;j<=u;j++)
	{
		fac=0;
		for(i=1;i<=j;i++)
		{
			if(j%i==0)
			fac=fac+1;
		}
		if(fac==2)
		printf("\n %d",&j);
		
	}
}
#include<stdio.h>
void main()
{
	int n,i,j;
	printf("enter no of rows:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=0;j<i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	
}
#include<stdio.h>
void main()
{
	int n,i,j,fac=0,fc;
	printf("enter no of rows:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=0;j<i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	for(i=1;i<=n;i++)
	{
		for(j=0;j<i;j++)
		{
			printf("%d\t",fac=fac+1);
		}
		printf("\n");
	}
	for(i=1;i<=n;i++)
	{
		fc=0;
		for(j=0;j<i;j++)
		
		{
			printf("%d\t",fc=fc+1);
		}
		printf("\n");
	}
}


*/
#include<stdio.h>
void main()
{
	int 
}
