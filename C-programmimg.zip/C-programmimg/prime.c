#include<stdio.h>
void main()
{
	int n,i,fac,j;
	printf("enter a no:");
	scanf("%d",&n);
	printf("the prime  numbers are:\n");
	
	for(i=1;i<=n;i++)
	{
		fac=0;
		for(j=1;j<=i;j++)
		{
			if(i%j==0)
			{
				fac=fac+1;
			}
		}
		if(fac==2)
		printf("%d\n",i);
		
	}
}
