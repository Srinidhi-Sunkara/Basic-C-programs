
//program to show the rules of a quadratic equation//
#include<stdio.h>
void main()
{
	int d,b,a,c;
	printf("ax2+bx+c=0\n");
	printf("enter the values of b,a,c:\n");
	scanf("%d%d%d",&b,&a,&c);
	printf("the equation is of the form %dx2+%dx+%d=0\n",a,b,c);
	d=(b*b)-(4*a*c);
	if(d<0)
	printf("the entered equation has imaginary roots");
	else if(d==0)
	printf("the entered equation har real and equal roots");
	else
	printf("the entered equation has r eal and unequal roots");
}

