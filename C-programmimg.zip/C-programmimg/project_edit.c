#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
struct address
{
                int hno;
                char street[40];
                char city[40];
                char state[40];
};

struct patient
{
                char name[40];
                char fname[40];
                int age;
                char bg[3];
                char gender;
                int regn;
                struct address a;
                char ph[10];
                char disease[60];
                char doc_name[40];
                char history[200];
                char date[10];
                char treatment[40];
                char med[40];
};
void main()
{
     FILE *fp,*ft;
     char another,ch;
     int reg;char pname[40];
     int iF=0;
     long int recsize;
     struct patient p;
     fp=fopen("pat.dat","rb+");
     if(fp==NULL)
        {
            fp=fopen("pat.dat","wb+");
            if(fp==NULL)
            {
                puts("\nSorry!! Cannot open file");
                exit(1);
            }
        }
        recsize=sizeof(p);
		printf("Enter the registration number:");
		scanf("%d",&reg);
		rewind(fp);
		if(p.regn==reg)
		{
			iF=1;
			printf("\n This registration number already exists.Enter another one");
		}
		if(iF==0)
		{
			fseek(fp,0,SEEK_END);
			strcpy(p.regn,reg);
			fflush(stdin);
			printf("patient name:");
			gets(p.name);
			printf("guardian name:");
			gets(p.fname);
			printf("\ngender:");
			scanf("%c",&p.gender);
			printf("blood group");
			scanf("%s",p.bg);
			printf("\naddress");
			printf("house no:");
			scanf("%d",&p.a.hno);
			fflush(stdin);
			printf("colony:");
			scanf("%s",p.a.street);
			printf("city:");
			fflush(stdin);
			gets(p.a.city);
			printf("state:");
			scanf("%s",p.a.state);
			printf("ph no:");
			scanf("%s",p.ph);
			fflush(stdin);
			printf("disease:");
			gets(p.disease);
			printf("doctor name:");
			gets(p.doc_name);
			printf("history:");
			gets(p.history);			

       }
	   printf("\n Enter the registration number of the patient to modify:");
	   scanf("%s",reg);
	   rewind(fp);
	   while(fread(&p,recsize,1,fp)==1)
	   {
	   	if(strcmp(p.regn,reg)==0)
	   	{
	   		fflush(stdin);
	   		printf("patient name:");
			gets(p.name);
			printf("guardian name:");
			gets(p.fname);
			printf("\ngender:");
			scanf("%c",&p.gender);
			printf("blood group");
			scanf("%s",p.bg);
			printf("\naddress");
			printf("house no:");
			scanf("%d",&p.a.hno);
			fflush(stdin);
			printf("colony:");
			scanf("%s",p.a.street);
			printf("city:");
			scanf("%s",p.a.city);
			printf("state:");
			scanf("%s",p.a.state);
			printf("ph no:");
			scanf("%s",p.ph);
			fflush(stdin);
			printf("disease:");
			gets(p.disease);
			printf("doctor name:");
			gets(p.doc_name);
			printf("history:");
			gets(p.history);			

		   }
	   		   	
	   }
}     
