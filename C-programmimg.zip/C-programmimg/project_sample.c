#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
struct address
{
                int hno;
                char street[40];
                char city[40];
                char state[40];
};

struct patient
{
                char name[40];
                char fname[40];
                int age;
                char bg[3];
                char gender;
                char regn[10];
                struct address a;
                char ph[10];
                char disease[60];
                char doc_name[40];
                char history[200];
                char date[10];
                char treatment[40];
                char med[40];
};
void main()
{
     FILE *fp,*ft;
     char another,ch;
     char reg[20],pname[40];
     int iF=0;
     long int recsize;
     struct patient p;
     fp=fopen("pat.txt","r+");
     if(fp==NULL)
        {
            fp=fopen("pat.txt","w+");
            if(fp==NULL)
            {
                puts("\nSorry!! Cannot open file");
                exit(1);
            }
        }
        recsize=sizeof(p);
		printf("Enter the registration number:");
		scanf("%s",reg);
		rewind(fp);
		if(strcmp(p.regn,reg)==0)
		{
			iF=1;
			printf("\n This registration number already exists.Enter another one");
		}
		if(iF==0)
		{
			fseek(fp,0,SEEK_END);
			strcpy(p.regn,reg);
			fprintf(fp,"%s",p.regn);
			fflush(stdin);
			printf("patient name:");
			gets(p.name);
			fprintf(fp,"%s",p.name);
			printf("guardian name:");
			gets(p.fname);
			fprintf(fp,"%s",p.fname);
			printf("\ngender:");
			scanf("%c",&p.gender);
			fprintf(fp,"%c",p.gender);
			printf("blood group");
			scanf("%s",p.bg);
			fprintf(fp,"%s",p.bg);
			printf("\naddress");
			printf("\nhouse no:");
			scanf("%d",&p.a.hno);
			fprintf(fp,"%d",p.a.hno);
			fflush(stdin);
			printf("colony:");
			scanf("%s",p.a.street);
			fprintf(fp,"%s",p.a.street);
			printf("city:");
			fflush(stdin);
			gets(p.a.city);
			fprintf(fp,"%s",p.a.city);
			printf("state:");
			scanf("%s",p.a.state);
			fprintf(fp,"%s",p.a.state);
			printf("ph no:");
			scanf("%s",p.ph);
			fprintf(fp,"%s",p.ph);
			fflush(stdin);
			printf("disease:");
			gets(p.disease);
			fprintf(fp,"%s",p.disease);
			printf("doctor name:");
			gets(p.doc_name);
			fprintf(fp,"%s",p.doc_name);
			printf("history:");
			gets(p.history);		
			fprintf(fp,"%s",p.history);	

       }
	   
}     
