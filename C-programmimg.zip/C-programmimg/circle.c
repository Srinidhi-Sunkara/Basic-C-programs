#include<stdio.h>
void main()
{
	float r,c,a;
	printf("enter the radius of circle:\n");
	scanf("%f",&r);
	c=(2*(3.14)*r);
	printf("THe circumference of the circle:%f\n",c);
	a=((3.14)*r*r);
	printf("the area of the circle is:%f",a);
}
