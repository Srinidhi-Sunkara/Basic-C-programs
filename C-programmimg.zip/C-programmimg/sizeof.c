#include<stdio.h>
void main()
{
	printf("the size of int is:%d\n",sizeof(int));
	printf("the size of short int is:%d\n",sizeof(short int));
	printf("the size of long int is:%d\n",sizeof(long int));
	printf("the size of float is:%d\n",sizeof(float));
    printf("the size of double is:%d\n",sizeof(double));
    printf("the size of char is:%d\n",sizeof(char));
    
}
