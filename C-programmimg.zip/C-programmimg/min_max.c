//program to print min and max of a list of numbers//
#include<stdio.h>
void main()
{
	int n,min,max,num,i;
	printf("enter the no of elements in a list:");
	scanf("%d",&n);
	printf("enter a no:");
	scanf("%d",&min);
	max=min;
//	printf("%d\t%d",min,max);
	for(i=1;i<n;i++)
	{
			printf("enter a no:");
	        scanf("%d",&num);
	        if(num>max)
	        max=num;
	        else
	        min=num;
	}
	printf("the minimum of entered list is:%d\n",min);
	printf("the maximum of entered list is:%d\n",max);
	
}
