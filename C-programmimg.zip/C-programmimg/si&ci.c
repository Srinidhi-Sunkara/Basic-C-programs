#include<stdio.h>
#include<math.h>
void main()
{
	int p,i,n;
	float si,ci;
	printf("enter principal,intrest rate in percentage and term of the loan:");
	scanf("%d%d%d",&p,&i,&n);
	si=p*i*n;
	ci=p*(pow((1+i),n)-1);
	printf("the compund intrest is%f\nthe simple intrest is%f",ci,si);
	
}
