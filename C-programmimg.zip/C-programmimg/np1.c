#include<stdio.h>
void main()
{
  int N,r=0,flag=0;
  scanf("%d",&N);
  while(r==0&&N>1)
  {
    r=N%2;
    
    N=N/2;
  }
   
  if(flag==0)
    printf("NO");
  else
    printf("YES");
}
