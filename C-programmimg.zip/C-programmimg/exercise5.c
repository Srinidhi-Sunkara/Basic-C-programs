
//menu oriented
#include<stdio.h>
#include<string.h>
void main()
{
	char a[100],b[100],es=" ",c[100];
	int count=0,i=0,j=0,ch,mid,temp;
	printf("1.length\n2.copy the string\n3.concatenate with other string\n4.reversing the string\n5.convertiong to upper case:\n");
	printf("enter a number:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
			printf("\nenter a string:");
			fflush(stdin);
	        gets(a);
	        
	        while(a[i]!='\0')
	       {
	        	count=count+1;
	        	i=i+1;
	        }
	
	        printf("\nthe number of letters in the string:%d",count);
	        break;
	    case 2:
	    	printf("enter a string:");
	    	fflush(stdin);
	        gets(a);
	        
	        while(a[i]!='\0')
	    	{
	    		b[i]=a[i];
	    		i++;
			}
			printf("\nThe copied string:");
			puts(b);
		    break;
		case 3:
		    printf("enter string1:");
		    fflush(stdin);
	        gets(a);
	        printf("\nenter string2:");
			fflush(stdin);
			gets(b);			
			while(a[i]!='\0')
			{
				c[j]=a[i];
				i=i+1;
				j=j+1;
			}
			i=0;
			while(b[i]!='\0')
			{
				c[j]=b[i];
				i=i+1;
				j=j+1;
			}
			printf("after concatenation:");
			puts(c);
			break;
		case 4:
		    printf("enter a string:");
			fflush(stdin);
			gets(a);
			
			
	//		while(a[i]!='\0')
	//		{
	//			es=(es*10)+a[i];
	//			i++;
	//		}
	       mid=strlen(a)/2;
	       while(i!=mid)
	       {
	       	temp=a[i];
	       	a[i]=a[strlen(a)-1-i];
	       	a[strlen(a)-1-i]=temp;
	       	i++;
		   }
	
	
	
	        	
	printf("The reverse of the string is:");
	puts(a);	
			break;
		case 5:
			printf("enter a string:");
			fflush(stdin);
			gets(a);
				
			while(a[i]!='\0')
			{
				if(a[i]>=97&&a[i]<=122)
				{
					b[i]=a[i]-32;
					i++;
				}
				else
				{
					b[i]=a[i];
					i++;
					
				}
			}
			b[i]='\0';
			printf("after converting to upper case:");
			fflush(stdin);
			puts(b);
			break;
		default:
		    printf("invalid input");	
			
			
	}
}/*//2.

#include<stdio.h>
void main()
{
	char a[1000];
	int i=0,vowel=0,bs=0,sen=0,cha=0,count=0;
	fflush(stdin);
	printf("enter a paragraph:\n");
	gets(a); 
	//puts(a);
	while(a[i]!='\0')
	{
		
	
		if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U')
		vowel+=1;
		else if(a[i]==' ')
		{
		bs+=1;
		count++;
	}
		else if(a[i]=='.'||a[i]=='\n'){
		sen+=1;
		count++;}
		else if((a[i]>=65&&a[i]<=91)||(a[i]>=97&&a[i]<=123))
		cha=cha+1;
		
		i++;
	}
	printf("The no of\n\tvowels:%d\n\tblank spaces:%d\n\tsentenses:%d\n\tcharacters:%d\n\twords:%d",vowel,bs,sen,cha,count);
}*/
/*3.
#include<stdio.h>
void main()
{
	char a[100][100],temp;
	int i,j,small,n;
	fflush(stdin);
	printf("enter the no of names required:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		
		for(j=0;j<100;j++)
		scanf("%c",&a[i][j]);
	}
	for(i=0;i<n;i++)
	{
		small=i;
	    for(j=i+1;j<n;j++)
		{
			if(a[j][100]<a[i][100])
			small=j;
		}
		temp=a[small][100];
		a[small][100]=a[i][100];
		a[i][100]=temp;
	}
		for(i=0;i<n;i++)
	{
		printf("\n");
		for(j=0;j<n;j++)
		printf("%c",a[i][j]);
	}
	
}
#include<stdio.h>
#include<string.h>
void main()
{
	char a[7]={'a','@','g','h','%',';','j'},temp;
	int mid,i=0,j=0;
	mid=strlen(a)/2;
	for(i=0;i<=mid;i++)
	{
		
		for(j=strlen(a)-1;j>=mid;j++)
		{
			if((a[i]>='a'&&a[i]>='z')||(a[i]>='A'&&a[i]>='Z')){
			if((a[j]>='a'&&a[j]>='z')||(a[j]>='A'&&a[j]>='Z'))
			{
				temp=a[j];
				a[j]=a[i];
				a[i]=temp;
				break;
			}}
			
			
		}
	}
	puts(a);
}
#include<stdio.h>
#include<conio.h>
#include<string.h>
int main()
{
	int i,j,k,c,l=0,n=0;
	char s[30],word[10],rword[10],str[300];
	printf("\n enter:");fflush(stdin);
	gets(s);
	printf("\n length of st=%d",strlen(s));
	printf("\n cap");
	for(i=0;s[i]!='\0';i++)
	{
		if(s[0]>='a'&&s[0]<='z')
		s[0]-=32;
		else if(s[i]==" ")
		{
			i++;
			if(s[i]>='a'&&s[i]<='z')
			{
				s[i]-=32;
				continue;		}
			}
			else
			continue;
			
			
			}
			printf("\n%s",s);
			printf("\n enter wrp");
			scanf("%s",&word);
			printf("enter the rpw");
			scanf("%s",rword);
			while(str[i]!='\0')
			{
				j=0;
				k=i;
				while(s[k]==word[i]&&word[j]!='\0')
				{
					k++;j++;
									}
			if(word[j]=='\0')
			{
				c=k;
				while(rword[l]!='\0')
				{
					str[n]=rword[l];
					l++;
					n++;
				}
				
			}
			str[n]='\0';
			i=0;
			while(str[i]!='\0')
			{
				printf("%s",str[i]);
				i++;
			}
			puts(str);
			printf("\n sar %s",str);
			getch();
			return 0;
			
			}
			
	}*/
	
	
		

