#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
struct address
{
                int hno;
                char street[40];
                char city[40];
                char state[40];
};

struct patient
{
                char name[40];
                char fname[40];
                int age;
                char bg[3];
                char gender;
                char regn[10];
                struct address a;
                char ph[10];
                char disease[60];
                char doc_name[40];
                char history[200];
                char date[10];
                char treatment[40];
                char med[40];
};
void main()
{
     FILE *fp,*ft;
     char another,ch;
     char reg[20],pname[40];
     int iF=0;
     long int recsize;
     struct patient p;
     fp=fopen("pat.dat","rb+");
     if(fp==NULL)
        {
            fp=fopen("pat.dat","wb+");
            if(fp==NULL)
            {
                puts("\nSorry!! Cannot open file");
                exit(1);
            }
        }
        recsize=sizeof(p);
		printf("Enter the registration number:");
		scanf("%s",reg);
		rewind(fp);
		if(strcmp(p.regn,reg)==0)
		{
			iF=1;
			printf("\n This registration number already exists.Enter another one");
		}
		if(iF==0)
		{
			fseek(fp,0,SEEK_END);
			strcpy(p.regn,reg);
			fwrite(p.regn,recsize,1,fp);
			fflush(stdin);
			printf("\npatient name:");
			gets(p.name);
			fwrite(p.name,recsize,1,fp);
			printf("\nguardian name:");
			gets(p.fname);
		    fwrite(p.fname,recsize,1,fp);
			printf("\ngender:");
			scanf("%c",&p.gender);
			fwrite(p.gender,recsize,1,fp);
			printf("blood group");
			scanf("%s",p.bg);
			fwrite(p.bg,recsize,1,fp);
			printf("\naddress");
			printf("\nhouse no:");
			scanf("%d",&p.a.hno);
			fwrite(p.a.hno,recsize,1,fp);
			fflush(stdin);
			printf("colony:");
			scanf("%s",p.a.street);
			fwrite(p.a.street,recsize,1,fp);
			printf("city:");
			fflush(stdin);
			gets(p.a.city);
			fwrite(p.a.city,recsize,1,fp);
			printf("state:");
			scanf("%s",p.a.state);
			fwrite(p.a.state,recsize,1,fp);
			printf("ph no:");
			scanf("%s",p.ph);
			fwrite(p.ph,recsize,1,fp);
			fflush(stdin);
			printf("disease:");
			gets(p.disease);
			fwrite(p.disease,recsize,1,fp);
			printf("doctor name:");
			gets(p.doc_name);
			fwrite(p.doc_name,recsize,1,fp);
			printf("history:");
			gets(p.history);		
			fwrite(p.history,recsize,1,fp);	

       }
	   
}     
