#include<stdio.h>
struct student
{
	int rno;
	char name[25];
	int marks[5];
	int total;
	int rank;
};
void main()
{
	int i,j;
	struct student s[10],temp;
	for(i=0;i<10;i++)
	{
		printf("enter the registration number:\n");
		scanf("%d",&s[i].rno);
		printf("enter the name:");
		fflush(stdin);
	gets(s[i].name);
      //  scanf("%s",&s[i].name);
        s[i].total=0;
		for(j=0;j<5;j++)
		{
			printf("enter the marks of %d subject:",j+1);
			scanf("%d",&s[i].marks[j]);
			s[i].total+=s[i].marks[j];
		}
		
	}
	for(i=0;i<10;i++)
	{
		for(j=i+1;j<10;j++)
		{
			if(s[i].total<s[j].total)
			{
				temp=s[i];
				s[i]=s[j];
				s[j]=temp;
			}
		}
		s[i].rank=i+1;
	}
	for(i=0;i<10;i++)
	{
		printf("\nregno:%d\tname:%s\tsub1:%d\tsub2:%d\tsub3:%d\tsub4:%d\tsub5:%d\t\ttotal:%d\trank:%d",s[i].rno,s[i].name,s[i].marks[0],s[i].marks[1],s[i].marks[2],s[i].marks[3],s[i].marks[4],s[i].total,s[i].rank);
	
	
	}	
}

