#include<stdio.h>
void main()
{
	int sum=0,n,r,temp=0,i=0;
	printf("enter a no:");
	scanf("%d",&n);
	while(n>0)
	{
		r=n%10;
		sum=sum+r;
		temp=(temp*10)+r;
		i=i+1;
		n=n/10;
	}
	printf("sum of the digits:%d\n",sum);
	printf("total no of digits:%d\n",i);
	printf("reverse of a number:%d",temp);
}
