/*#include<stdio.h>
float ncr(int n,int r);
int fac(int n)

{
	int fact=1,i;
	if(n==0)
	return 1;
	else{
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	return fact;}
 	
}
void main()
{
	int n,r;
	
	printf("enter 2 nos:");
	scanf("%d%d",&n,&r);
	ncr(n,r);
}
float ncr(int n,int r)
{
		int nf,rf,nrf,x,y;
		float c;
		x=n-r;
	nf=fac(n);
	rf=fac(r);
	nrf=fac(x);
	y=rf*nrf;
	c=((nf)/y);
	printf("%f",c);
}
#include<stdio.h>
void main()
{
	int n,i=0,j,r,a[100];
	printf("enter a no:");
	scanf("%d",&n);
	while(n>0)
	{
		r=n%2;
		a[i]=r;
		i++;
		n=(int)n/2;
		
	}
	for(j=i;j>=0;j++)
	{
		printf("%d",a[j]);
	}
}
#include<stdio.h>
 
main()
{
   int n, i = 3, count, c;
 
   printf("Enter the number of prime numbers required\n");
   scanf("%d",&n);
 
   if ( n >= 1 )
   {
      printf("First %d prime numbers are :\n",n);
      printf("2\n");
   }
 
   for ( count = 2 ; count <= n ;  )
   {
      for ( c = 2 ; c <= i - 1 ; c++ )
      {
         if ( i%c == 0 )
            break;
      }
      if ( c == i )
      {
         printf("%d\n",i);
         count++;
      }
      i++;
   }         
 
}
#include<stdio.h>
void main()
{
	int n,r,i=0,j;
	char a[100];
	scanf("%d",&n);
	while(n>0)
    {
    	r=n%16;
    	if(r<10)
    	{
    		a[i]=r+48;
		}
		else
		a[i]=r+55;
		i++;
		n=n/16;
	}
	for(j=0;j<=i;j++)
	{
		printf("%c",a[j]);
	}
}*/
#include <stdio.h>
 
// A recursive binary search function. It returns 
// location of x in given array arr[l..r] is present, 
// otherwise -1
int binarySearch(int arr[], int l, int r, int x)
{
   if (r >= l)
   {
        int mid = l + (r - l)/2;
 
        // If the element is present at the middle 
        // itself
        if (arr[mid] == x)  
            return mid;
 
        // If element is smaller than mid, then 
        // it can only be present in left subarray
        if (arr[mid] > x) 
            return binarySearch(arr, l, mid-1, x);
 
        // Else the element can only be present
        // in right subarray
        return binarySearch(arr, mid+1, r, x);
   }
 
   // We reach here when element is not 
   // present in array
   return -1;
}
 
int main(void)
{
   int arr[] = {2, 3, 4, 10, 40};
   int n = sizeof(arr)/ sizeof(arr[0]);
   int x = 10;
   int result = binarySearch(arr, 0, n-1, x);
   (result == -1)? printf("Element is not present in array")
                 : printf("Element is present at index %d",
                                                   result);
   return 0;
}

