/*#include<stdio.h>
#include<conio.h>
#include<math.h>
int len(int n);
void main()
{
	int n,i,j,sum=0,r;
	
	printf("enter the binary:");
	scanf("%d",&n);
	i=0;
	int length=len(n);
	while(i<length)
	{
		r=n%10;
		sum+=r*(pow(2,i));
		n=n/10;
		i++;
	}
	printf("%d",sum);
}
len(int n)
{
	int r,i=0;
	while(n>0)
	{
		
		n=n/10;
		i++;
	}
	return i;
}	
#include<stdio.h>
#include<conio.h>
#include<math.h>
int len(int n);
void main()
{
	int n,i,j,sum=0,r;
	
	printf("enter the binary:");
	scanf("%d",&n);
	i=0;
	int length=len(n);
	while(i<length)
	{
		r=n%10;
		sum+=r*(pow(8,i));
		n=n/10;
		i++;
	}
	printf("%d",sum);
}
len(int n)
{
	int r,i=0;
	while(n>0)
	{
		
		n=n/10;
		i++;
	}
	return i;
}	//convertion of decimal to binary
#include<stdio.h>
#include<conio.h>
#include<math.h>
int _bin(int n)
{
	int  r,i,c=0,sum=0;
	i=0;
	while(n>=1)
	{
		r=n%2;
		sum+=r*pow(10,c);
		c++;
	
		n=n/2;
	}
	return sum;
}
void main()
{
int n,x;
printf("enter a no:");
scanf("%d",&n);
x=_bin(n);
printf("%d",x);
}
#include<stdio.h>
#include<conio.h>
#include<math.h>
int _bin(int n)
{
	int  r,i,c=0,sum=0;
	i=0;
	while(n>=1)
	{
		r=n%16;
		sum+=r*pow(10,c);
		c++;
	
		n=n/16;
	}
	return sum;
}
void main()
{
int n,x;
printf("enter a no:");
scanf("%d",&n);
x=_bin(n);
printf("%d",x);
}
*//*
#include<stdio.h>
int bs(int,int,int,int);
void main()
{
	int i,j,n,a[100],x;
	printf("enter the number of elements in the array:\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter the element to be found:\n");
	scanf("%d",&x);
	printf("%d",bs(a,x,0,n));
}
int bs(int a[],int x,int start,int end)
{
	int mid;
	mid=(start+end)/2;
	if(a[mid]==x)
	return mid;
	else
	{
		if(a[mid]>x)
		bs(a,x,start,mid);
		else
		bs(a,x,mid,end);
	}
}
//decimal to binary

#include<stdio.h>
void bin(int dec);
void main()
{
	int dec,a[10],i,r,j;
	printf("enter the decimal number:");
	scanf("%d",&dec);
	bin(dec);
}
void bin(int dec)
{
	int i,j,r,a[100];
	for(i=0;dec>0;i++)
	{
		r=dec%2;
		a[i]=r;
		dec=dec/2;
	}
	printf("the binary form of entered number is:\n");
	for(j=i-1;j>=0;j--)
	{
		
		printf("%d",a[j]);
	}
}
//binary to decimal
#include<stdio.h>
#include<math.h>
void main()
{
	int n,i,j,r,sum=0,a[10];
	printf("enter a binary number:");
	scanf("%d",&n);
	for(i=0;n>0;i++)
	{
		r=n%10;//important
		a[i]=r;
		n=n/10;
	}
	for(j=0;j<i;j++)
	{
	//	printf("%d",a[j-i+1]);
		sum+=((a[i-j-1])*(pow(2,j)));
	}
	printf("the decimal form of entered number is:%d",sum);
}
//decimal to octal
#include<stdio.h>
void main()
{
	int n,i,r,a[10],j;
	printf("enter a decimal number:");
	scanf("%d",&n);
	for(i=0;n>0;i++)
	{
		r=n%8;
		a[i]=r;
		n=n/8;
	}
	printf("\nThe octal form of entered number is:");
	for(j=i-1;j>=0;j--)
	{
		printf("%d",a[j]);
	}
}
#include<stdio.h>
#include<math.h>
void main()
{
	int n,i,j,r,sum=0,a[10];
	printf("enter an octal number:");
	scanf("%d",&n);
	for(i=0;n>0;i++)
	{
		r=n%10;//important
		a[i]=r;
		n=n/10;
	}
	for(j=0;j<i;j++)
	{
	//	printf("%d",a[j-i+1]);
		sum+=((a[i-j-1])*(pow(8,j)));
	}
	printf("the decimal form of entered number is:%d",sum);
}*/
#include<stdio.h>
int bs(int a[],int,int,int);
void main()
{
	int a[10],i=0,n,num;
	int found1;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\n enter the number to be found:");
	scanf("%d",&num);
	found1=bs(a,num,0,n);
	if(found1==0)
	printf("not found");
	else
	printf("found");
}
int bs(int a[],int num,int start,int end)
{
	int mid,found=0;
	while(end>=start){	
	mid=(start+end)/2;
	
	if(a[mid]==num)
	{found=1;
	break;}

	else if(a[mid]>num)
		{
			bs(a,num,start,mid-1);
		}
	else if(a[mid]<num)
		{
			bs(a,num,mid+1,end);
		}
	
}
return found;
}
/*
#include<stdio.h>
void bin(int dec);
void main()
{
	int dec,a[10],i,r,j;
	printf("enter the decimal number:");
	scanf("%d",&dec);
	bin(dec);
}
void bin(int dec)
{
	int i,j,r,a[100],sum=0;
	for(i=0;dec>0;i++)
	{
		r=dec%8;
		sum+=r*pow(10,i);
		dec=dec/8;
		
	}
	printf("%d",sum);
u}*/
