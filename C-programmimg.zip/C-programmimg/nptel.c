#include<stdio.h>
void main()
{
  int m[5][5],i,j,r=3,c=3,flag=1;
  printf("%d\t%d",r,c);
  for(i=0;i<r;i++)
  {
    for(j=0;j<c;j++)
    {
    	printf("\t");
    	
      scanf("%d",&m[i][j]);
      
    }
    printf("\n");
  
  }
  for(i=0;i<r;i++)
  {
    for(j=0;j<c;j++)
    {
      if(i<j)
        printf("0");
      else
        printf("%d",m[i][j]);
        printf("\t");
    }
    printf("\n");
  }
}
