#include<stdio.h>
void main()
{
  int a[10][10],b[10][10],i,j,r,c;
  scanf("%d%d",&r,&c);
  for(i=0;i<r;i++)
  {
    for(j=0;j<c;j++)
    {
      scanf("%d",&a[i][j]);
    }
    
  }
  for(i=0;i<c;i++)
  {
    for(j=0;j<r;j++)
    {
      b[i][j]=a[j][i];
      printf("%d\t",b[i][j]);
    }
    printf("\n");
  }
}
