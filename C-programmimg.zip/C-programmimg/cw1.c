#include<stdio.h>
void main()
{
	int n,i=0,f=0,f1=-1,f2=1;
	printf("enter no:");
	scanf("%d",&n);
	while(i<n)
	{
		f=f1+f2;
		printf("%d\t",f);
		f1=f2;
		f2=f;
		i=i+1;
	}
	
}
