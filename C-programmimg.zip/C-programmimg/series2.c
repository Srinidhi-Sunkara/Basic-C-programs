#include<stdio.h>
#include<math.h>
void main()
{
	int n,x,i;
	float sum=1,j;
	printf("enter a number:");
	scanf("%d",&n);
	printf("enter the value of x:");
	scanf("%d",&x);
	for(i=1;i<n;i++)
	{
		j=pow(x,i);
		sum=sum+(1/j);
	}
	printf("%f",sum);
}
