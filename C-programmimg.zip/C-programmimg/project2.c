#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
struct address
{
                int hno;
                char street[40];
                char city[40];
                char state[40];
};

struct patient
{
                char name[40];
                char fname[40];
                int age;
                char bg[3];
                char gender;
                int regn;
                struct address a;
                char ph[10];
                char disease[60];
                char doc_name[40];
                char history[200];
                char date[10];
                char treatment[40];
                char med[40];
};
void main()
{
     FILE *fp,*ft;
     char another,ch,name[20];
     int a,ch1;
     int reg;char pname[40];
     int iF=0;
     long int recsize;
     struct patient p;
     fp=fopen("pat.dat","ab+");
    
            if(fp==NULL)
            {
                puts("\nSorry!! Cannot open file");
                exit(1);
            }
        
        recsize=sizeof(p);
        fread(&p,recsize,1,fp);
        printf("1.to create a record\n2.edit a record\n3.search a record\n4.list of all records\n");
        printf("enter a choice:");
        scanf("%d",&ch1);
        switch(ch1)
		{
			case 1:
				{
		printf("Enter the registration number:");
		scanf("%d",&reg);
		rewind(fp);
	    /*while(getw(fp)!=EOF)
        {
            if(p.regn==reg)
              {
                    iF=1;
                    printf("\n\t\tTHIS REGISTRATION NUMBER ALREADY EXISTS. ENTER ANOTHER ONE");
                                           
              }
        }*/
		if(iF==0)
		{
			fseek(fp,0,SEEK_END);
			p.regn=reg;
			fflush(stdin);
			printf("\npatient name:");
			gets(p.name);
			printf("\nguardian name:");
			gets(p.fname);
		    printf("\ngender:");
			scanf("%c",&p.gender);
			printf("blood group");
			scanf("%s",p.bg);
			printf("\naddress");
			printf("\nhouse no:");
			scanf("%d",&p.a.hno);
			fflush(stdin);
			printf("colony:");
			scanf("%s",p.a.street);
			printf("city:");
			fflush(stdin);
			gets(p.a.city);
			printf("state:");
			scanf("%s",p.a.state);
			
			printf("ph no:");
			scanf("%s",p.ph);
			
			fflush(stdin);
			printf("disease:");
			gets(p.disease);
			
			printf("doctor name:");
			gets(p.doc_name);
			
			printf("history:");
			gets(p.history);		
			fwrite(&p,recsize,1,fp);
	}break;
		}
		case 2:
			{
				printf("\n Enter the name of the patient to modify:");
	   scanf("%s",name);
	   rewind(fp);
	   while(fread(&p,recsize,1,fp)==1)
	   {
	   	if(strcmp(p.name,name)==0)
	   	{
	   		fflush(stdin);
	   		printf("patient name:");
			gets(p.name);
			printf("guardian name:");
			gets(p.fname);
			printf("\ngender:");
			scanf("%c",&p.gender);
			printf("blood group");
			scanf("%s",p.bg);
			printf("\naddress");
			printf("house no:");
			scanf("%d",&p.a.hno);
			fflush(stdin);
			printf("colony:");
			scanf("%s",p.a.street);
			printf("city:");
			scanf("%s",p.a.city);
			printf("state:");
			scanf("%s",p.a.state);
			printf("ph no:");
			scanf("%s",p.ph);
			fflush(stdin);
			printf("disease:");
			gets(p.disease);
			printf("doctor name:");
			gets(p.doc_name);
			printf("history:");
			gets(p.history);	
			fwrite(&p,recsize,1,fp);		

		   }
		}
		break;

       }
       case 3:
       	{
       		printf("\n Enter the name of the patient to search:");
	        scanf("%s",name);
	        rewind(fp);
	        while(fread(&p,recsize,1,fp)==1)
            {
                if(strcmp(p.name,name)==0)
                   {
                   	fflush(stdin);
	   		printf("patient name:");
			puts(p.name);
			printf("guardian name:");
			puts(p.fname);
			printf("\ngender:");
			printf("%c",p.gender);
			printf("blood group");
			printf("%s",p.bg);
			printf("\naddress");
			printf("house no:");
			printf("%d",p.a.hno);
			fflush(stdin);
			printf("colony:");
			printf("%s",p.a.street);
			printf("city:");
			printf("%s",p.a.city);
			printf("state:");
			printf("%s",p.a.state);
			printf("ph no:");
			printf("%s",p.ph);
			fflush(stdin);
			printf("disease:");
			puts(p.disease);
			printf("doctor name:");
			puts(p.doc_name);
			printf("history:");
			puts(p.history);	
	          }
        }
        break;
		
		}
		case 4:{
			rewind(fp);                                     
            while(fread(&p,recsize,1,fp)==1)
               {
               	fflush(stdin);
               	      printf("patient name:");
			puts(p.name);
			printf("guardian name:");
			puts(p.fname);
			printf("\ngender:");
			printf("%c",p.gender);
			printf("blood group");
			printf("%s",p.bg);
			printf("\naddress");
			printf("house no:");
			printf("%d",p.a.hno);
			fflush(stdin);
			printf("colony:");
			printf("%s",p.a.street);
			printf("city:");
			printf("%s",p.a.city);
			printf("state:");
			printf("%s",p.a.state);
			printf("ph no:");
			printf("%s",p.ph);
			fflush(stdin);
			printf("disease:");
			puts(p.disease);
			printf("doctor name:");
			puts(p.doc_name);
			printf("history:");
			puts(p.history);
               }
               
                                                                     
			break;
		}
 
	   
}}
