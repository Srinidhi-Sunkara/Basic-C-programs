#include<stdio.h>
void main()
{
	int n,r,sum,temp,i=1;
	printf("enter the upper limit");
	scanf("%d",&n);
	
	while(i<n)
	{
		temp=i;sum=0;
		while(i>0)
		{
			r=i%10;
	    	sum=sum+(r*r*r);
	    	i=i/10;}
	        if(temp==sum)
	    	{
	    		printf("%d",temp);
			
			}
		i=i+1;
			
		
		}
		
	
		
		
	}
	

