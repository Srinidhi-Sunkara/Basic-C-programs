/*#include<stdio.h>
void main()
{
	int a,b,temp;
	printf("enter first no:");
	scanf("%d",&a);
	printf("enter second no:");
	scanf("%d",&b);
	temp=a;
	a=b;
	b=temp;
	printf("\n after swapping no1:%d",a);
	printf("\n after swapping no2:%d",b);
}*/
#include<stdio.h>
void main()
{
	int a,b,temp;
	printf("enter first no:");
	scanf("%d",&a);
	printf("enter second no:");
	scanf("%d",&b);
	a=a+b;
	b=a-b;
	a=a-b;
	printf("\n after swapping no1:%d",a);
	printf("\n after swapping no2:%d",b);
}
