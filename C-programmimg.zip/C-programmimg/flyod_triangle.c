#include<stdio.h>
void main()
{
	int i,n,j,fac,fc;
	printf("enter the value of n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=0;j<i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	fac=0;
	for(i=1;i<=n;i++)
	{
		for(j=0;j<i;j++)
		{
			fac=fac+1;
			printf("%d\t",fac);
		}
		printf("\n");
	}
	for(i=1;i<=n;i++)
	{
		fc=0;
		for(j=0;j<i;j++)
		{
			fc=fc+1;
			printf("%d\t",fc);
		}
		printf("\n");
	}
}
