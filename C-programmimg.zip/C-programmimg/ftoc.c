#include<stdio.h>
void main()
{
	float c,c1,f,f1;
	printf("enter celsius temperature:\n");
	scanf("%f",&c);
	f1=(c*1.8)+32;
	printf("its value in fahrenheit is%f\n",f1);
	printf("enter fahrenheit temperature:\n");
	scanf("%f",&f);
	c1=(0.555555 )*(f-32);
	printf("its value in celcius is%f",c1);
	
	
}
