#include<stdio.h>
#include<stdlib.h>
struct node{
int a;
struct node *next;
};
void main()
{int n,no,pos,count=0,ans;
struct node *start,*temp,*first,*second,*third,*fourth,*fifth;
    
first=(struct node*)malloc(sizeof(struct node));
second=(struct node*)malloc(sizeof(struct node));
third=(struct node*)malloc(sizeof(struct node));
fourth=(struct node*)malloc(sizeof(struct node));
fifth=(struct node*)malloc(sizeof(struct node));
if(first==NULL)
printf("no memory");
printf("\nenter first element");
scanf("%d",&first->a);
printf("\nenter second element");
scanf("%d",&second->a);
printf("\nenter third element");
scanf("%d",&third->a);
printf("\nenter fourth element");
scanf("%d",&fourth->a);
printf("\nenter fifth element");
scanf("%d",&fifth->a);
first->next=second;
second->next=third;
third->next=fourth;
fourth->next=fifth;
fifth->next=NULL;
printf("linked list created successfully");
printf("\n menu program\n1.insert node\n2.delete node\n3.update value\n4.display linked list");
printf("\nchoose option");
scanf("%d",&n);
switch(n)
{
case 1:{
printf("\nenter position where the new node is to be inserted");
scanf("%d",&pos);
start=first;
while(count<pos-2)
{start=start->next;count++;}
temp=(struct node*)malloc(sizeof(struct node));
printf("\nenter value of new node");
scanf("%d",&temp->a);
temp->next=NULL;
if(start->next==NULL)
start->next=temp;
else
{
temp->next=start->next;
start->next=temp;
}
printf("\nelement inserted successfully\n");
start=first;
while(start!=NULL)
{printf("%d->",start->a);
start=start->next;}
printf("NULL");
free(temp);
break;
}
case 2:{
printf("\nenter the position node to be deleted");
scanf("%d",&pos);
start=first;
while(count<pos-2)
{start=start->next;
temp=start->next;count++;}
start->next=temp->next;
temp->next=NULL;
start=first;
while(start!=NULL)
{printf("%d->",start->a);
start=start->next;}
printf("NULL");
free(temp);
break;
}
case 4:{
start=first;
printf("\n");
while(start!=NULL)
{printf("%d->",start->a);
start=start->next;}
printf("NULL");
break;
}
case 3:{
printf("\nenter the number of the node whose value is to be updated");
scanf("%d",&pos);
start=first;
while(count<pos-1)
{start=start->next;count++;}
printf("enter the new value");
scanf("%d",&start->a);
printf("\nvalue updated successfully\n");
start=first;
while(start!=NULL)
{printf("%d->",start->a);
start=start->next;}
printf("NULL");
break;
}
}
}
