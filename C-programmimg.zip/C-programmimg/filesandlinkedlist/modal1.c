/*#include<stdio.h>
#include<conio.h>
void main()
{
	int *p,n,i,j,temp;
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%d",(p+i));
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(*(p+i)>*(p+j))
			{
				temp=*(p+i);
				*(p+i)=*(p+j);
				*(p+j)=temp;
			}
		}
	}
	for(i=0;i<n;i++){
		printf("%d\n",*(p+i));
	}
}*/
#include<stdio.h>
void main()
{
	int n,i=3,count,c;
	scanf("%d",&n);
	if(n>=1)
	{
		printf("2\n");
	}
	for(count=2;count<=n;){
		for(c=2;c<=(i-1);c++)
		{
			if(i%c==0)
			break;
		}
		if(c==i)
		{
			printf("%d\n",i);
			count++;
		}
		i++;
		
	}
}
