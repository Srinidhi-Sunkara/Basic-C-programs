
/*16. Insert, update, delete and append telephone details of an individual or a company into a
telephone directory using random access file.
17. Count the number of account holders whose balance is less than the minimum balance
using sequential access file. 
*/
#include<stdio.h>
#include<conio.h>
#include<string.h>
struct tel{
	char name[100];
	char ph[10];
};
void main()
{
	FILE *fp,*ft;int ch;char n[100];
	struct tel t;
	fp=fopen("te.txt","ab+");
		ft=fopen("tel.txt","ab+");
	if(fp==NULL)
	{
		exit(1);
	}
	printf("1.insert\n2.update\n3.delete\n4.list\n");
	printf("enter a choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:{
			printf("enter the name:");
			scanf("%s",t.name);
			printf("enter phone number:");
	fflush(stdin);
	scanf("%s",t.ph);
	fwrite(&t,sizeof(t),1,fp);
	break;
}
       case 2:{
       	printf("enter the name to modify details:");
       	scanf("%s",n);
       	 while(fread(&t,sizeof(t),1,fp)==1)
	   {
       	if(strcmp(n,t.name)==0)
       	{
       		printf("enter the name:");
			scanf("%s",t.name);
			printf("enter phone number:");
	fflush(stdin);
	scanf("%s",t.ph);
	fwrite(&t,sizeof(t),1,fp);
       		
		   }}
		break;
	   }
	   case 3:{
	   	printf("enter the name of the record to delete:");
	   	scanf("%s",n);
	   	 while(fread(&t,sizeof(t),1,fp)==1)
	   {
       	if(strcmp(n,t.name)==0)
       	{
       		continue;
       	}
       	else
       	{
       		fwrite(&t,sizeof(t),1,ft);
		}
		fclose(fp);
		 while(fread(&t,sizeof(t),1,ft)==1)
	   {
       	
       		fwrite(&t,sizeof(t),1,fp);
		}
		
	   	
		break;
	   }
}
	case 4:{
		printf("name\tphone number\n");
		while(fread(&t,sizeof(t),1,fp)==1)
		{
			if(feof(fp))
			break;
			printf("%s\t",t.name);
			printf("%s\n",t.ph);
			
		}
		break;
	}

}
}
