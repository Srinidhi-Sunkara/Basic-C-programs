
#include<stdio.h>
struct stud
{
    char name[100];
    int id,em,pm,cm,mm,csm;
};
void main()
{
    struct stud s[5];
    int x,i;
    printf("Enter the number of students");
    scanf("%d",&x);
    for(i=0;i<x;i++)
    {
        printf("Enter the name of student %d:",i+1);
        scanf("%s",&s[i].name);
        printf("Enter the student ID:");
        scanf("%d",&s[i].id);
    printf("Enter the marks obtained in English:");
        scanf("%d",&s[i].em);
    printf("Enter the marks obtained in Physics:");
        scanf("%d",&s[i].pm);
    printf("Enter the marks obtained in Chemistry:");
        scanf("%d",&s[i].cm);
    printf("Enter the marks obtained in Maths:");
        scanf("%d",&s[i].mm);
    printf("Enter the marks obtained in Computer Science:");
        scanf("%d",&s[i].csm);
    s[i].em=(s[i].em*2)*0.2;
        s[i].mm=(s[i].mm*2)*0.2;
        s[i].pm=(s[i].pm*2)*0.2;
        s[i].cm=(s[i].cm*2)*0.2;
        s[i].csm=(s[i].csm*2)*0.2;
    }
    for (i=0;i<x;i++)
    {
    printf("\n");
         printf(" \n Name of the student:%s",s[i].name);
         printf(" \n Student ID is :%d",s[i].id);
         printf(" \n English internal marks :%d",s[i].em);
         printf(" \n Maths internal marks: %d",s[i].mm);
         printf(" \n Physics internal marks:%d",s[i].pm);
         printf(" \n Chemistry internal marks:%d",s[i].cm);
         printf(" \n Computer Science internal marks:%d",s[i].csm);
       
    }
}


