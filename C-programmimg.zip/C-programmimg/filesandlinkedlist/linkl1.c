#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
void main()
{
	int n,pos,count=0;
	struct node *start,*first,*second,*third,*fourth,*fifth,*temp1,*temp;
	first=(struct node *)malloc(sizeof(struct node));
	second=(struct node *)malloc(sizeof(struct node));
	third=(struct node *)malloc(sizeof(struct node));
	fourth=(struct node *)malloc(sizeof(struct node));
	fifth=(struct node *)malloc(sizeof(struct node));
    temp=(struct node *)malloc(sizeof(struct node));
    temp1=(struct node *)malloc(sizeof(struct node));
    if(first==NULL)
    {
    	printf("error");
    	exit(1);
	}
	printf("1.create\n1.insert\n2.delete\n3.traverse");
	scanf("%d",&n);
	printf("enter first element:\n");
    scanf("%d",&first->data);
	first->next=second;
	printf("enter second element:\n");
    scanf("%d",&second->data);
	second->next=third;
	printf("enter third element:\n");
    scanf("%d",&third->data);
    third->next=fourth;
    printf("enter fourth element:\n");
    scanf("%d",&fourth->data);
    fourth->next=fifth;
    	printf("enter fifth element:\n");
    scanf("%d",&fifth->data);
    fifth->next=NULL;
    start=first;
    switch(n)
    {
	case 1:
	{
			printf("enter the data to insert in the list:");
			scanf("%d",&temp->data);
			printf("enter the node postion to insert:");
			scanf("%d",&pos);
			start=first;
			while(count<pos-2)
			{
				start=start->next;
				count++;
			}
			temp->next=start->next;
			start->next=temp;
			start=first;
			while(start!=NULL)
			{
				printf("%d\t",(start->data));
				start=start->next;
			}
			break;
		}
		case 2:
			{
				printf("enter the postion to be deleted\n");
				scanf("%d",&pos);
				start=first;
				if(pos==1)
				{
					struct node *ptr;
					ptr=start;
					start=start->next;
					free(ptr);
				}
			
				
				
				break;
			}

}}


