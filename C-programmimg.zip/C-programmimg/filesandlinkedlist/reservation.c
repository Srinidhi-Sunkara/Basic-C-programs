#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct p{
	char train[100];
	int tn;
};
void main()
{
	FILE *fp,*ft;
	struct p p1;
	int ch;
	char t[100];
	fp=fopen("train.txt","ab+");
	if(fp==NULL){
		exit(1);
	}
	printf("1.add\n2.delete\n3.modify\n4.list");
	printf("enter choice");
	scanf("%d",&ch);
	switch(ch){
		case 1:{
			printf("enter train name:");
			scanf("%s",p1.train);
			printf("enter train no:");
			scanf("%d",&p1.tn);
			fwrite(&p1,sizeof(p1),1,fp);
			break;
		}
		case 2:{
			ft=fopen("train1.txt","ab+");
			if(ft==NULL)
			exit(1);
			printf("enter the train name:");
			scanf("%s",t);
			while(fread(&p1,sizeof(p1),1,fp)==1){
				if(strcmp(p1.train,t)==0){
					continue;
				}
				else{
					fwrite(&p1,sizeof(p1),1,ft);
				}
				
			}
			fclose(fp);
			fp=fopen("train.txt","wb+");
			rewind(ft);
			while(fread(&p1,sizeof(p1),1,ft)==1){
				fwrite(&p1,sizeof(p1),1,fp);
			}
			
			
			break;
		}
		case 3:{
			printf("enter the train name:");
			scanf("%s",t);
			while(fread(&p1,sizeof(p1),1,fp)==1){
				if(strcmp(p1.train,t)==0){
					continue;}
			else
			fwrite(&p1,sizeof(p1),1,ft);
				}
				printf("enter train name:");
			scanf("%s",p1.train);
			printf("enter train no:");
			scanf("%d",&p1.tn);
			fwrite(&p1,sizeof(p1),1,ft);
			fclose(fp);
			fp=fopen("train.txt","wb+");
			rewind(ft);
			while(fread(&p1,sizeof(p1),1,ft)==1){
				fwrite(&p1,sizeof(p1),1,fp);	
				//else{
				//	printf("not found");
				}
			
			
			break;
		}
		case 4:{
			while(fread(&p1,sizeof(p1),1,fp)==1){
				if(!feof(fp)){
					printf("%s\t",p1.train);
					printf("%d",p1.tn);
				}
			}
			
			break;
		}
	
}
}
