 //linear search
/*#include<stdio.h>
int main()
{
	int a[10],i=0,n,num;
	int found=0;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\n enter the number to be found:");
	scanf("%d",&num);
	for(i=0;i<n;i++)
	{
		if(a[i]==num)
		{	
			printf("entered element is found");
			found=1;
			break;
		}
	    
    }
	if(found==0)
	printf("the entered element is not found");	`
    getch();
	return 0;	
}
binary search
#include<stdio.h>
int main()
{
	int a[10],i=0,n,num;
	int mid,b=0,e,found=0;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\n enter the number to be found:");
	scanf("%d",&num);
	b=0,e=n-1;
	while(b<=e)
	{
		mid=(b+e)/2;
		if(a[mid]==num)
		{
			printf("element found");
			found=1;
			break;
		}
		else
		{
			if(a[mid]>num)
			e=mid-1;
			else
			b=mid+1;
		}
		
	}
	if(found==0)
	printf("the element not found");
	return 0;
}
duplicates
# include<stdio.h>
int main()
{
	int a[10],i,j,n,k,sum=0;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[i]==a[j])
			{
				sum=sum+1;
				for(k=j;k<n;k++)
				{
					a[j]=a[j+1];
				}
			}
			
		}
	}
	printf("after removing the duplicates");
	for(i=0;i<(n-(sum-1));i++)
	printf("%d",a[i]);
	return 0;
}
bubble sort*/
/*#include<stdio.h>
int main()
{
	int a[10],i,j,large,small,temp,n;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
				
			}
			
		}
	}
	for(i=0;i<n;i++)
	printf("%d",a[i]);
	printf("\nthe smallest element is %d",a[0]);
	printf("the largest element is:%d",a[n-1]);
	return 0;
}*/
/*Selection sort
#include<stdio.h>
int main()
{
	int a[10],i,j,large,small,temp,n;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	{
		small=i;
		for(j=i+1;j<n;j++)
		{
			if(a[small]>a[j])
			small=j;
		}
		temp=a[small];
		a[small]=a[i];
		a[i]=temp;
	}
	for(i=0;i<n;i++)
	printf("%d",a[i]);
	return 0;
}*/
//matrices menu
/*
#include<stdio.h>
int main()
{
	int a[10][10],b[10][10],c[10][10],i,j,k,n,s;
	float determinant=0;
	printf("1.+\n2.-\n3.*\n4.transpose\n5.determinant\n6.inverse\n7.scalar\n");
	printf("\nenter a choice");
	scanf("%d",&n);
	switch(n)
	{
		case 1:
			printf("enter the no of rows and columns");
			scanf("%d",&n);
			printf("enter the entries of matrice 1\n");
			for(i=0;i<n;i++)
			{
				for(j=0;j<n;j++)
				scanf("%d",&a[i][j]);
			}
			printf("enter the entries of matrice 2");
			for(i=0;i<n;i++)
			{
				for(j=0;j<n;j++)
				scanf("%d",&b[i][j]);
			}
			printf("after adding\n");
			for(i=0;i<n;i++)
			{
				printf("\n");
 				for(j=0;j<n;j++){
 					printf("\t");
				c[i][j]=a[i][j]+b[i][j];
				printf("%d",c[i][j]);
			}
		}break;
		case 2:
			printf("enter the no of rows and columns");
			scanf("%d",&n);
			printf("enter the entries of matrice 1");
			for(i=0;i<n;i++)
			{
				
				for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);}
							}
			printf("\nenter the entries of matrice 2:");			
			for(i=0;i<n;i++)
			{
				for(j=0;j<n;j++)
				scanf("%d",&b[i][j]);
			}
			printf("\nafter subtracting");
			
			for(i=0;i<n;i++)
			{
				printf("\n");
				for(j=0;j<n;j++){
					printf("\t");
				c[i][j]=a[i][j]-b[i][j];
				printf("%d",c[i][j]);
			}
		}break;
		case 3:
			printf("enter the no of rows and columns");
			scanf("%d",&n);
			printf("\nenter the entries of matrice1");
			for(i=0;i<n;i++)
			{
				for(j=0;j<n;j++)
				scanf("%d",&a[i][j]);
			}
			printf("enter the entries of matrice2");
			for(i=0;i<n;i++)
			{
				for(j=0;j<n;j++)
				scanf("%d",&b[i][j]);
			}
			printf("after multiplying");
			for(i=0;i<n;i++)
			{
				j=0;
				
				for(j=0;j<n;j++){
					c[i][j]=0;
					for(k=0;k<n;k++){
				c[i][j]+=a[i][k]*b[k][j];
				}
			}
	     	}
	     	for(i=0;i<n;i++)
			{printf("\n");
				for(j=0;j<n;j++){
				printf("%d",c[i][j]);printf("\t");}
			}
	     	
	     	break;
	    case 4:
			printf("enter the no of rows and columns");
			scanf("%d",&n);
			printf("\nenter the entries of matrice1");
			for(i=0;i<n;i++)
			{
				printf("\n");
				for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);}
			}
			
			for(i=0;i<n;i++)
			{
				printf("\n");
				for(j=0;j<n;j++){printf("\t");
			
				printf("%d",a[i][j]);
			}
		
			
		} 
			printf("\nafter transposing\n");
			for(i=0;i<n;i++)
			{
				printf("\n");
				for(j=0;j<n;j++){
				b[i][j]=a[j][i];printf("\t");
				printf("%d",b[i][j]);
			}
		} 
		break;
		case 5:
		    printf("Enter the 9 elements of matrix: ");
            for(i=0;i<3;i++)
                 for(j=0;j<3;j++)
                       scanf("%d",&a[i][j]);

           printf("\nThe matrix is\n");
                for(i=0;i<3;i++){
                 printf("\n");
                   for(j=0;j<3;j++)
                      printf("%d\t",a[i][j]);
                        }

            for(i=0;i<3;i++)
                  determinant = determinant + (a[0][i]*(a[1][(i+1)%3]*a[2][(i+2)%3] - a[1][(i+2)%3]*a[2][(i+1)%3]));	
            printf("the determinant of the matrix is %f:",determinant);
            break;
         case 6:
                printf("Enter the 9 elements of matrix: ");
                for(i=0;i<3;i++)
                   for(j=0;j<3;j++)
                      scanf("%d",&a[i][j]);

                printf("\nThe matrix is\n");
                for(i=0;i<3;i++){
                 printf("\n");
                   for(j=0;j<3;j++)
                     printf("%d\t",a[i][j]);
                } 

                for(i=0;i<3;i++)
                    determinant = determinant + (a[0][i]*(a[1][(i+1)%3]*a[2][(i+2)%3] - a[1][(i+2)%3]*a[2][(i+1)%3]));

                printf("\nInverse of matrix is: \n\n");
               for(i=0;i<3;i++){
                  for(j=0;j<3;j++)
                printf("%.2f\t",((a[(i+1)%3][(j+1)%3] * a[(i+2)%3][(j+2)%3]) - (a[(i+1)%3][(j+2)%3]*a[(i+2)%3][(j+1)%3]))/ determinant);
               printf("\n");}
               break;
         case 7:
		       printf("enter the no of rows and columns");
			   scanf("%d",&n);
			for(i=0;i<n;i++)
			{
				
				for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);} }
			printf("\n enter the scalar to be multiplied:");
			scanf("%d",&s);
			printf("\nAfter doing scalar multiplication\n");
			for(i=0;i<n;i++){
				for(j=0;j<n;j++)
				{
					printf("%d",(s*a[i][j]));
					printf("\t");
				}
				printf("\n");
			}	     
			break;
		default:
		   printf("invalid input");	
}}*//*//pallindrome
#include<stdio.h>
void main()
{
	int ch,i,j,rows,space,n=1,num=1;
	printf("enter the rows");
	scanf("%d",&rows);
	for(i=0;i<rows;i++)
	{
	for(space=1;space<=rows;space++)
	{
		printf(" ");
		
	}
	for(j=0;j<=i;j++)
	{
		if(j==0||i==0)
		{		
	    n=1;
	    }
		else
		{
		n=(n*(i-j+1))/j;
	    }
		printf("%d",n);
		
	}
}
	
}
#include <stdio.h>
int main()
{
    int rows, coef = 1, space, i, j;

    printf("Enter number of rows: ");
    scanf("%d",&rows);

    for(i=0; i<rows; i++)
    {
        for(space=1; space <= rows-i; space++)
            printf("  ");

        for(j=0; j <= i; j++)
        {
            if (j==0 || i==0)
                coef = 1;
            else
                coef = coef*(i-j+1)/j;

            printf("%4d", coef);
        }
        printf("\n");
    }

    return 0;
}
#include<stdio.h>

int main(){

  int a[3][3],i,j;
  float determinant=0;
  printf("Enter the 9 elements of matrix: ");
  for(i=0;i<3;i++)
      for(j=0;j<3;j++)
           scanf("%d",&a[i][j]);

  printf("\nThe matrix is\n");
  for(i=0;i<3;i++){
      printf("\n");
      for(j=0;j<3;j++)
           printf("%d\t",a[i][j]);
  }

  for(i=0;i<3;i++)
      determinant = determinant + (a[0][i]*(a[1][(i+1)%3]*a[2][(i+2)%3] - a[1][(i+2)%3]*a[2][(i+1)%3]));

   printf("\nInverse of matrix is: \n\n");
   for(i=0;i<3;i++){
      for(j=0;j<3;j++)
           printf("%.2f\t",((a[(i+1)%3][(j+1)%3] * a[(i+2)%3][(j+2)%3]) - (a[(i+1)%3][(j+2)%3]*a[(i+2)%3][(j+1)%3]))/ determinant);
       printf("\n");
   }

   return 0;
}
largest and smallest elements
#include<stdio.h>
int main()
{
	int a[10],i,j,large,small,temp,n;
	printf("enter the number of elements in the array:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	large=0;
	small=0;
	for(i=0;i<n;i++)
	{
		if(a[large]<a[i])
		large=i;
		else if(a[small]>a[i])
		small=i;
	}
	printf("largest element:%d",a[large]);
	printf("\nsmallest element:%d",a[small]);
}*/
//7.avg height
/*
#include<stdio.h>
void main()
{
	int h[100],count,i,n,ah=0;
	printf("\nEnter the number of persons:");
	scanf("%d",&n);
	printf("\nenter the entries:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&h[i]);
		ah+=h[i];
	}

	for(i=0;i<n;i++)
	{
		if(h[i]>(ah/n))
		count+=1;
	}
	printf("\nthe number of people above avg height:%d",count);
	
}*/
//8.populate
/*
#include<stdio.h>
void main()
{
	int a[100][100],i,n,j;
	float b[100];
	printf("enter the number of people:\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter the %d height in cm and weight in kg respectively:",i+1);
		for(j=0;j<2;j++)
		{
			scanf("%d",&a[i][j]);//0,0 will be height and 0,1 will be weight
		}
		
		b[i]=(float)((a[i][1])/(a[i][0]*a[i][0]*0.01*0.01));
		printf("%f",b[i]);
		
	}
	for(i=0;i<n;i++)
	{
		printf("\nthe bmi of %d person is:%f",(i+1),b[i]);
	}

}*/
#include<stdio.h>
#include<math.h>
void main()
{
	int a[6]={10,36,54,89,12,27},i,j,fac;
	for(i=0;i<6;i++)
	{
		if(((sizeof(cbrt(a[i])))==4))
				{
			a[i]=5;
		}
		else if((a[i]%4==0)&&(a[i]%6==0))
	   {
		a[i]=4;
	   }
	   else
	   {
	   	for(i=1;i<=a[i]+1;i++)
	   	{
	   		for(j=1;j<=i;j++){
	   		if(a[i]%j==0)
	   		fac+=1;}
		}
		if(fac==2)
		a[i]=3;
	   }
	
	}
	for(i=0;i<6;i++)
	printf("%d\n",a[i]);
}
